<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends CMS_Controller {
    
	public function index()
	{
            echo 'Index test...';
	}
        
        public function metodo2($var1, $var2)
        {            
            $this->template->add_js('template', 'script1', 'utf-8', TRUE, TRUE);
            $this->template->add_css('view', 'css1', 'print');
            $this->template->add_css('url', 'http://css2.css');
            $this->template->set('titulo', 'Mi titulo');
            $this->template->render('test');
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */