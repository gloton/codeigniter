<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{
		$this->load->view('welcome_message');
	}
        
        public function metodo2($var1, $var2)
        {
            echo $this->uri->segment(5) . '<br>';
            echo 'Metodo2 ' . $var1 . ' ' . $var2;
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */