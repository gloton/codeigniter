<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['cms_admin_panel_uri'] = 'admin/';


/* End of file cms.php */
/* Location: ./application/config/cms.php */