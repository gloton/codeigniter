<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['templates']['front']['default'] = [
    'regions' => ['header','main_menu','sidebar','footer'],
    'scripts' => [
        ['type' => 'base', 'value' => 'template_script1', 'options' => ['charset' => 'utf-8', 'defer' => TRUE, 'async' => TRUE]]
    ],
    'styles' => [
        ['type' => 'base', 'value' => 'template_style1', 'options' => ['media' => 'screen']]
    ]
];

$config['templates']['admin']['default'] = [
    'regions' => ['header','main_menu','sidebar','footer']
];

/* End of file templates.php */
/* Location: ./application/config/templates.php */