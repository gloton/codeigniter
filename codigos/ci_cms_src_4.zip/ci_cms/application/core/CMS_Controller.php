<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CMS_Controller extends CI_Controller 
{    
    private $admin_panel;
    
    public function __construct() 
    {
        parent::__construct();
        $this->load->config('cms');
        
        if( ! $this->config->item('cms_admin_panel_uri'))
        {
            show_error('Configuration error');
        }
        
        $this->admin_panel = trim(substr($this->config->item('cms_admin_panel_uri'), 0, -1));
        $this->load->library('template');
    }
    
    public function admin_panel()
    {
        return strtolower($this->uri->segment(1)) == $this->admin_panel;
    }
    
    public function admin_panel_uri()
    {
        return $this->config->item('cms_admin_panel_uri');
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */