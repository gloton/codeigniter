<h2>Vista test de la plantilla</h2>
<?=$titulo?>
