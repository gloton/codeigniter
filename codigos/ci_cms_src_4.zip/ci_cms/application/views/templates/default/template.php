<?=$_js?>

<?=$_css?>

<h1>Plantilla Default</h1>

<?php foreach($_content as $_view): ?>
    <?php include $_view;?>
<?php endforeach; ?>
